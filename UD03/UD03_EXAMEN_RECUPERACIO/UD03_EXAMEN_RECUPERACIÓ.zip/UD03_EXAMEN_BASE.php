<!DOCTYPE html>
<html>
<!-- Segueix les instruccions comentades per resoldre l'exercici -->
<!-- Quan apareix *CAMP elquesiga* fa referència a que has de mostrar el CAMP elquesiga que ve del formulari HTML fent servir echo de PHP -->
<!-- Afig un títol a la finestra del navegador que diga "Targeta de visita XXXXXXXX" on les XXXXXXXX serà el camp "estil" seleccionat per l'usuari que ve del formulari HTML (2 punt)-->
<!-- Utilitza un únic CSS per al HTML i el PHP (1 punt)-->
<!-- El present arxiu PHP conté errors, corregix i comenta (com més prop possible de l'error millor) tots aquells que trobes -->

<head>
    <meta charset="utf-8" />

<body>
    <!-- La taula té 3 files i dos columnes, revisa l'enunciat per a vore la distribució de les mateixes i saber quines s'han de combinar -->
    <!-- Completa el background de la taula amb el *CAMP estil* de manera que mostre el png amb nom de l'estil corresponent de la carpeta img (3 punts) -->
    <table background="">
        <!-- fila1 (amb una cel·la juntant les dos cel·les de la fila) (1 punt)-->
        
            
                <!-- *CAMP empresa* com a capçalera de nivell 1 (2 punts) -->
                
                <!-- *CAMP nom* i *CAMP cognoms* com a capçalera de nivell 2. Hi ha dos maneres de fer-ho, amb un sol php d'inici i final i concatenant els camps (4 punts) o obrir i tancar php per a cada camp (2 punts) -->
                
                <!-- *CAMP carrec* com a capçalera de nivell 3 (2 punts) -->
                
            
        
        <!-- fila 2 (amb dos cel·les), amb un selector d'id o de classe a la fila d'acord amb el CSS per a donar format al peu (1 punt) -->
        
            
                Contacte:
            
            
                <!-- *CAMP url* de manera que siga un enllaç a la url (2 punts) -->
                <a href=""></a>
            
        
        <!-- fila 3 (amb dos cel·les), amb un selector d'id o de classe a la fila d'acord amb el CSS per a donar format al peu (1 punt) -->
        
            
                <!-- *CAMP telefon* (1 punt) -->
                
            
            
                <!-- *CAMP email* de manera que siga un enllaç al correu (2 punts) -->
                <a href="mailto:"></a>
            
        
    
    

                
</html>

<!-- TOTAL 25 punts -->