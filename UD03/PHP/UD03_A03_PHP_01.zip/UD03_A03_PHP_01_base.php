<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Exercici PHP 1</title>
    <!-- Enllaça un CSS per a donar format al HTML resultant d'este PHP. El CSS haurà de tindre una unica regla que faça que les etiquetes de tipus Capçalera 1 siga de color "coral" -->
</head>

<body>
    <!-- Afig una etiqueta de capçalera 1 que incloga la seqüència PHP necessaria per a mostrar "Hola mon!". Consulta del diapositives del tema si no recordes com -->

</body>

</html>