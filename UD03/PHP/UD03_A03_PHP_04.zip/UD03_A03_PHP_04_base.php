<!DOCTYPE html>
<html>
<!-- Segueix les instruccions comentades per resoldre l'exercici -->
<head>
    <meta charset="utf-8" />
    <title>Curriculum Vitae</title>
    <!-- inclou la linea que falta per a fer referència al CSS (serà el mateix que utilitz l'HTML)-->
</head>

<body>
    <h1>CURRICULUM VITAE</h1>
    <table>
        <tr>
            <td>Nom i cognoms:</td>
            <td>
                <?php echo $_POST["nom"]." ".$_POST["cognoms"]; ?>
            </td>
            <td>
                <!--
                    1.- Assigna un selector CSS a esta (i sols esta) etiqueta <td> segons l'estil que poses al CSS i de manera la cel·la s'alinie a la dreta.
                    2.- Fes que 'combine' les 4 files de la taula per a deixar espai a la foto
                    3.- Inclou la etiqueta per a mostrar la imatge foto.jpg amb una amplaria de 100 pixels 
                -->

            </td>
        </tr>
        <tr>
            <td>Adreça postal:</td>
            <td>
                <!-- Inclou el codi PHP necessàri per a mostrar les dades corresponents del formulari-->
            </td>
        </tr>
        <tr>
            <td>E-correu:</td>
            <td>
                <!-- Inclou el codi PHP necessàri per a mostrar les dades corresponents del formulari-->
            </td>
        </tr>
        <tr>
            <td>Data naixement:</td>
            <td>
                <!-- Inclou el codi PHP necessàri per a mostrar les dades corresponents del formulari-->
            </td>
        </tr>
    </table>
    <h2>Formació Reglada</h2>
        <!-- Afig les etiquetes necessàries per a una llista com la del exemple -->
        <!-- Afig les etiquetes span que necessites i assigna-los el css corresponent segons l'exemple de l'enunciat -->
        2019-2021 Cicle Formatiu Grau mitjà "Sistemes microinformàtics en Xarxa". IES Mestre Ramon Esteve
        2014-2019 ESO IES Mestre Ramon Esteve
    <h2>Idiomes</h2>
        <!-- Afig les etiquetes necessàries per a una llista com la del exemple -->
        <!-- Afig les etiquetes span que necessites i assigna-los el css corresponent segons l'exemple de l'enunciat -->
        Castella Alt
        Valencià Mitjà
        Anglès Baix

</body>

</html>